 <div class="main">
    <div class="content">
    	<div class="cartoption">		
			<div class="cartpage">
			    	<h2>Your Cart</h2>
						<div class="not_found">
								<h3>404 erro</h3>
						</div>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>